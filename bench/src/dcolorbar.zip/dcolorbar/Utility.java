package dcolorbar;

import java.io.*;
import java.nio.*;
import java.awt.*;
import java.awt.image.*;
import java.util.Random;
import javax.imageio.*;
import javax.swing.*;

import edu.mines.jtk.io.*;
import edu.mines.jtk.awt.*;
import edu.mines.jtk.dsp.*;
import edu.mines.jtk.sgl.*;
import edu.mines.jtk.util.*;
import edu.mines.jtk.interp.*;
import edu.mines.jtk.mosaic.*;
import edu.mines.jtk.ogl.Gl.*;

import static edu.mines.jtk.util.ArrayMath.*;
/*
 *  
 * @author Elias Arias, Colorado School of Mines, CWP
 * @version 19.1.2015
 */

public class Utility {

  private static String path = 
    "/Users/earias/Home/git/ea/bench/src/dcolorbar/data/";

  /**
   * Converts a 1D array of doubles into an array of floats.
   * @param d array[n1] of doubles to be converted.
   * @return array[n1] of floats.
   */
  public static float[] f(double[] x) {
    int n1 = x.length;
    float[] f = new float[n1];
    for (int i1=0; i1<n1; ++i1)
      f[i1] = (float)x[i1];
    return f;
  }

  /**
   * Reads a binary file.
   * @param n1 the length of floats in the 1st-dimension
   * @param fileName the name of the file to be read
   * @return array[n1] of floats read from file
   */
  public static float[] read(int n1, String fileName) {
    ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
    try {
      ArrayInputStream ais = new ArrayInputStream(fileName,byteOrder);
      float[] x = new float[n1];
      ais.readFloats(x);
      ais.close();
      return x;
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Reads a binary file.
   * @param n1 the length of floats in the 1st-dimension
   * @param fileName the name of the file to be read
   * @return array[n1] of floats read from file
   */
  public static float[] readL(int n1, String fileName) {
    ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
    try {
      ArrayInputStream ais = new ArrayInputStream(fileName,byteOrder);
      float[] x = new float[n1];
      ais.readFloats(x);
      ais.close();
      return x;
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }


  /**
   * Reads a binary file.
   * @param n1 the length of floats in the 1st-dimension
   * @param n2 the length of floats in the 2nd-dimension
   * @param fileName the name of the file to be read
   * @return array[n2][n1] of floats read from file
   */
  public static float[][] read(int n1, int n2, String fileName) {
    ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
    try {
      ArrayInputStream ais = new ArrayInputStream(fileName,byteOrder);
      float[][] x = new float[n2][n1];
      ais.readFloats(x);
      ais.close();
      return x;
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Reads a binary file.
   * @param n1 the length of floats in the 1st-dimension
   * @param n2 the length of floats in the 2nd-dimension
   * @param fileName the name of the file to be read
   * @return array[n2][n1] of floats read from file
   */
  public static float[][] readL(int n1, int n2, String fileName) {
    ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
    try {
      ArrayInputStream ais = new ArrayInputStream(fileName,byteOrder);
      float[][] x = new float[n2][n1];
      ais.readFloats(x);
      ais.close();
      return x;
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Reads a binary file.
   * @param n1 the length of floats in the 1st-dimension
   * @param n2 the length of floats in the 2nd-dimension
   * @param n3 the length of floats in the 3rd-dimension
   * @param fileName the name of the file to be read
   * @return array[n3][n2][n1] of floats read from file
   */
  public static float[][][] read(int n1, int n2, int n3, String fileName) {
    ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
    try {
      ArrayInputStream ais = new ArrayInputStream(fileName,byteOrder);
      float[][][] x = new float[n3][n2][n1];
      ais.readFloats(x);
      ais.close();
      return x;
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Reads a binary file.
   * @param n1 the length of floats in the 1st-dimension
   * @param n2 the length of floats in the 2nd-dimension
   * @param n3 the length of floats in the 3rd-dimension
   * @param fileName the name of the file to be read
   * @return array[n3][n2][n1] of floats read from file
   */
  public static float[][][] readL(int n1, int n2, int n3, String fileName) {
    ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
    try {
      ArrayInputStream ais = new ArrayInputStream(fileName,byteOrder);
      float[][][] x = new float[n3][n2][n1];
      ais.readFloats(x);
      ais.close();
      return x;
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Writes seismic data to binary file.
   * @param x array[n1] of data to write to the binary file
   * @param fileName name of output binary file
   */
  public static void write(float[] x, String fileName) {
    ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
    try {
      ArrayOutputStream aos = new ArrayOutputStream(fileName,byteOrder);
      aos.writeFloats(x);
      aos.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Writes seismic data to binary file.
   * @param x array[n2][n1] of data to write to the binary file
   * @param fileName name of output binary file
   */
  public static void writeL(float[] x, String fileName) {
    ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
    try {
      ArrayOutputStream aos = new ArrayOutputStream(fileName,byteOrder);
      aos.writeFloats(x);
      aos.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Writes seismic data to binary file.
   * @param x array[n2][n1] of data to write to the binary file
   * @param fileName name of output binary file
   */
  public static void write(float[][] x, String fileName) {
    ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
    try {
      ArrayOutputStream aos = new ArrayOutputStream(fileName,byteOrder);
      aos.writeFloats(x);
      aos.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Writes seismic data to binary file.
   * @param x array[n2][n1] of data to write to the binary file
   * @param fileName name of output binary file
   */
  public static void writeL(float[][] x, String fileName) {
    ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
    try {
      ArrayOutputStream aos = new ArrayOutputStream(fileName,byteOrder);
      aos.writeFloats(x);
      aos.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Writes seismic data to binary file.
   * Java default byteorder is BIG_ENDIAN.
   * @param x array[n3][n2][n1] of data to write to the binary file
   * @param fileName name of output binary file
   */
  public static void write(float[][][] x, String fileName) {
    ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
    try {
      ArrayOutputStream aos = new ArrayOutputStream(fileName,byteOrder);
      aos.writeFloats(x);
      aos.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Writes seismic data to binary file.
   * Java default byteorder is BIG_ENDIAN.
   * @param x array[n3][n2][n1] of data to write to the binary file
   * @param fileName name of output binary file
   */
  public static void writeL(float[][][] x, String fileName) {
    ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
    try {
      ArrayOutputStream aos = new ArrayOutputStream(fileName,byteOrder);
      aos.writeFloats(x);
      aos.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Makes a 1D array into a 2D array assuming the 1D array is column major.
   */
  public static float[][] make2D(int n1, int n2, float[] x) {
    Check.argument(n1*n2 == x.length, "n1*n2 != x.length dimension error");
    float[][] y = new float[n2][n1];
    for (int i2=0; i2<n2; ++i2)
      for (int i1=0; i1<n1; ++i1)
        y[i2][i1] = x[i1+i2*n1];
    return y;
  }

  /**
	 * Returns RGB (red, green, blue) components of an image read from a file.
	 * @param fileName the name of the file containing a JPEG image.
	 * @return array of RGB components; the components (red,green,blue) are 
	 * stored in {rgb[0],rgb[1],rgb[2]}.
	 */
	public static float[][][] rgbFromFile(String fileName) {
		BufferedImage bi = null;
		try {
			File file = new File(fileName);
			bi = ImageIO.read(file);
		} catch (IOException ioe) {
			throw new RuntimeException(ioe);
		}
		int w = bi.getWidth();
		int h = bi.getHeight();
		int[] pixels = bi.getRGB(0,0,w,h,null,0,w);
		float[][][] rgb = new float[3][h][w];
		for (int i=0,k=0; i<h; ++i) {
			for (int j=0; j<w; ++j,++k) {
				int p = pixels[k];
				int r = (p>>16)&0xff;
				int g = (p>> 8)&0xff;
				int b = (p>> 0)&0xff;
				rgb[0][i][j] = (float)r/256.0f;
				rgb[1][i][j] = (float)g/256.0f;
				rgb[2][i][j] = (float)b/256.0f;
			}
		}
		return rgb;
	}


  public static void plot(float[] rgb1, float[] rgb2) {
    SimpleFrame sf = new SimpleFrame(AxesOrientation.XRIGHT_YIN_ZDOWN);
    PointGroup pg1 = new PointGroup(0.02f,rgb1,rgb1);
    PointGroup pg2 = new PointGroup(0.01f,rgb2,rgb2);
    sf.getWorld().addChild(pg1);
    sf.getWorld().addChild(pg2);
    ViewCanvas vc = sf.getViewCanvas();
    vc.setBackground(Color.BLACK);
    OrbitView ov = sf.getOrbitView();
    //ov.setEyeToScreenDistance(3018.87); // for consistency with brooks
    //ov.setWorldSphere(new BoundingSphere(0.5*n1,0.5*n1,0.5*n1,radius));
    //ov.setAzimuthAndElevation(50.0,15.0);
    ov.setScale(1.0);
    sf.setVisible(true);
    //sf.paintToFile(_paths+title+".png");
  }

  public static void plot(Sampling s1, Sampling s2, float[][] f) {
    PlotPanel pp = new PlotPanel(1,1,PlotPanel.Orientation.X1DOWN_X2RIGHT);
    PixelsView pv = pp.addPixels(s1,s2,f);

    java.awt.image.IndexColorModel icm = ColorMap.GRAY_YELLOW_RED;
    String fn = "gray_yellow_red";
    ColorMap cm = new ColorMap(icm);
    pv.setColorModel(ColorMap.setAlpha(icm,1.0));
    int ns = 256;
    Sampling s = new Sampling(ns,1.0/ns,0.0);
    float[] vals = f(s.getValues());
    float[] rgb = cm.getRgbFloats(vals);
    writeL(rgb,path+fn+".bin");

    pv.setInterpolation(PixelsView.Interpolation.NEAREST);
    pp.addTiledView(pv);
    pp.setHLabel("Traces");
    pp.setVLabel("Samples");
    pp.addColorBar("amplitude");
    pp.setColorBarWidthMinimum(150);
    PlotFrame pf = new PlotFrame(pp);
    //pf.paintToPng(720,(1920f-1)/720,path+fn+".png");
    pf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pf.setSize(850,600);
    pf.setVisible(true);
  }

  /**
   * Makes a 2D array into a 1D array such that the 1D array is column major.
   */
  public static float[] make1D(float[][] x) {
    int n2 = x.length;
    int n1 = x[0].length;
    float[] y = new float[n1*n2];
    for (int i2=0; i2<n2; ++i2)
      for (int i1=0; i1<n1; ++i1)
        y[i1+i2*n1] = x[i2][i1];
    return y;
  }
  

  public static void trace(String s) {
    System.out.println(s);
  }
}
